#ifndef __EVENT_H_
#define __EVENT_H_

#include "include.h"

#define TREAT_EVT 			  		0x1
#define LED_BLINK_EVT         0x2
#define SHUTDOWN_EVT          0x4
#define KEY_EVT               0x8


#define BAT_EVT        			  0x10
#define UART_EVT              0x40

extern unsigned char eventBuff;

void EventProcess();
void EventSet(unsigned char event);
void EventClear(unsigned char event);

#endif

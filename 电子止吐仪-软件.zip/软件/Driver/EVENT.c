#include "EVENT.h"

unsigned char eventBuff;

void EventSet(unsigned char event)
{
	eventBuff |= event; 	
}

void EventClear(unsigned char event)
{
 	eventBuff &= ~event;
}

void EventProcess()
{
	if(eventBuff&LED_BLINK_EVT)
	{
		LED_Blink();
	 	EventClear(LED_BLINK_EVT);
	}

	if(eventBuff&SHUTDOWN_EVT)
	{
		CCAPM0 = 0x40;  //DAC no output
		CHL = 0;
		CHR = 0;
		LED_R_OFF;
		LED_Display(OFF);
		LED_Display(OFF);
		PowerEn = 0;
		EventClear(SHUTDOWN_EVT); 	
		while(1);
	}
	
	if(eventBuff&BAT_EVT)
	{
		BatProcess();

		EventClear(BAT_EVT);
	}
	
	if(eventBuff&KEY_EVT)
	{
		KeyCount();
		EventClear(KEY_EVT);
	}
	
	
	//if(eventBuff&UART_EVT)
//	{
//		if(Battery.state == high)
//			uart_printf("h\r\n");
//		else
//			uart_printf("l\r\n");


	//	uart_printf("now state is ");
	//	sprintf((char * )buf , "adc is %2.1f" , (float)Battery.adc[1]);
	//	uart_printf(buf);
//		switch(Battery.state)
//		{
//			case 0:
//				uart_printf("low\r\n");
//				break;
//			case 1:
//				uart_printf("high\r\n");
//				break;
//			case 2:
//				uart_printf("full\r\n");
//				break;
//			case 3:
//				uart_printf("unfull\r\n");
//				break;
//			default:break;
//		}
	//	EventClear(UART_EVT);
	//}
}


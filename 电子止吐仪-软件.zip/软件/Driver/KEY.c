#include "KEY.h"

Key_Typedef keyPower;

void KeyScan()
{
	if(Power)
	{
		if(keyPower.press==nopress&&keyPower.count>=SHORT_PRESS_VALUE)
		{
			keyPower.press = shortpress;	
		}
		else if(keyPower.press==shortpress&&keyPower.count>=LONG_PRESS_VALUE)
		{
		 	keyPower.press = longpress;
			CCAPM0 = 0x40;  //DAC no output
			CHL = 0;
			CHR = 0;
			LED_R_OFF;
			LED_Display(OFF);
			LED_Display(OFF);
			DisableAllInterrupts;
			PowerEn = 0;
			while(!Dc_On);
			EnableAllInterrupts;
		}	
	}
	else
	{
		switch(keyPower.press)
		{
		 	case shortpress:	
				keyPower.press = nopress;
				OuTu.str++;
				if(OuTu.str>4)
					OuTu.str = 0;
				Blue.count = 0;
				Blue.state = 0;
				EventSet(LED_BLINK_EVT);
				break;
			case longpress:
				keyPower.press = nopress;
				break;
			default:break;
		}
	}	
}

void KeyCount()
{
	if(Power)
	{
		StrChangeMode = 0;
		StrChangeDelay = 0;
		StrBuf = 0;
		StrChange = 0;
		if(keyPower.count<3000)
		{
				keyPower.count++;
		}
	}
	else
	{
		keyPower.count = 0;
	}
}

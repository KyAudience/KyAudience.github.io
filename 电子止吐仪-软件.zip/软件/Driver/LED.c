#include "LED.h"

#define LedLevel 90
#define LedFrequency 100

LED_BLINK_Type_Def Blue;
LED_Breath_Type_Def Red_Breath;
LED_BLINK_Type_Def Red_Blink;

void LED_Display(LED_Type_Def state)	
{
	int i=0;
	if(state==ON)
	{
	 	for(i=0;i<7;i++)
		{
		 	switch(i)
			{
			 	case 0:
					ALL_LED_OFF;
					break;
				case 1:
					LED1_ON;
					break;
				case 2:
					LED2_ON;
					break;
				case 3:		
					LED3_ON;
					break;
				case 4:
					LED4_ON;
					break;
				case 5:
					LED5_ON
					break;
				case 6:
					ALL_LED_OFF;
					break;
				default:break;
			}
			Delayms(100);
		}
	}
	else if(state==OFF)
	{
	 	for(i=0;i<7;i++)
		{
		 	switch(i)
			{
			 	case 0:
					ALL_LED_OFF;
					break;
				case 1:
					LED5_ON;
					break;
				case 2:
					LED4_ON;
					break;
				case 3:		
					LED3_ON;
					break;
				case 4:
					LED2_ON;
					break;
				case 5:
					LED1_ON;
					break;
				case 6:
					ALL_LED_OFF;
					break;
				default:break;
			}
			Delayms(100);
		}	
	}
}

void LED_Blink()
{
	if(Blue.state==1)
	{
		Blue.state = 0;
		Blue.count = 2000;
		ALL_LED_OFF;
	}
	else if(Blue.state==0)
	{
		Blue.state = 1;
	 	Blue.count = 100;
		switch(OuTu.str)
		{
			case 0:
				LED1 = 0;
				LED2 = 1;
				LED3 = 1;
				LED4 = 1;
				LED5 = 1;
				break;
			case 1:
				LED1 = 0;
				LED2 = 0;
				LED3 = 1;
				LED4 = 1;
				LED5 = 1;
				break;
			case 2:
				LED1 = 0;
				LED2 = 0;
				LED3 = 0;
				LED4 = 1;
				LED5 = 1;
				break;
			case 3:
				LED1 = 0;
				LED2 = 0;
				LED3 = 0;
				LED4 = 0;
				LED5 = 1;
				break;
			case 4:
				LED1 = 0;
				LED2 = 0;
				LED3 = 0;
				LED4 = 0;
				LED5 = 0;
				break;
			default:break;
		}
	}
}

void LED_CHARGE(void)
{
	if(CHRG==1)
	{
			LED1=1;
			LED1_R=1;
			LED2=1;
			LED3=1;
			LED4=1;
			LED5=1;
	}
	else
	{
		if(Battery.state==unfull)
		{
			ALL_LED_OFF;
			LED_Breath();
		}
		else
		{
			LED1=1;
			LED1_R=1;
			LED2=1;
			LED3=1;
			LED4=1;
			LED5=1;
		}	
	}	
}

void LED_LowBat_Blink(void)
{
		if(Red_Blink.count==250)
		{
			LED_R_ON;
		}
		else if(Red_Blink.count==0)
		{
			LED_R_OFF;
			Red_Blink.count = 500;
		}
}

void LED_Breath_Frequency(void)
{
    if(Red_Breath.LedWidth == 0)
    {
      Red_Breath.LedWidthState = 1;
    }
    else if(Red_Breath.LedWidth == LedFrequency)
    {
      Red_Breath.LedWidthState = 0;
    }
    if(Red_Breath.LedWidthState == 1)
    {
      Red_Breath.LedWidth++;
    }
    if(Red_Breath.LedWidthState == 0)
    {
      Red_Breath.LedWidth--;
    }
}

void LED_Breath(void)
{
    switch(Red_Breath.LedState)
    {
      case 0:
        Red_Breath.LedBright++;
        if(Red_Breath.LedBright>=LedLevel)
          Red_Breath.LedState = 1;	
        break;
      case 1:
        Red_Breath.LedBright--;
        if(Red_Breath.LedBright<1)
          Red_Breath.LedState = 0;
        break;
    }
    
    if(Red_Breath.LedBright == 0)
		{
      LED_R_OFF;
		}
    else
    {
      if(Red_Breath.LedWidth < Red_Breath.LedBright)
      {
        LED_R_ON;
      }
      else
      {
        LED_R_OFF;
      }
    }	
}

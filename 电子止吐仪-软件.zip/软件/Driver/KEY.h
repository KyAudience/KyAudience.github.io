#ifndef __KEY_H_
#define __KEY_H_

#include "include.h"

#define SHORT_PRESS_VALUE 		50
#define LONG_PRESS_VALUE  		1500
#define KEY_COUNT_MAX    			3000 

typedef struct
{
	char press;
 	int count;
}Key_Typedef;

enum Key_Press
{
	nopress = 0,
	shortpress,
	longpress,	 	
};

extern Key_Typedef keyPower;

void KeyScan();
void KeyCount();

#endif

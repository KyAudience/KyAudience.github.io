#include "TREAT.h"

bit StrChangeMode = 0;
char StrChangeDelay = 0;
char StrBuf = 0;
char StrChange = 0;
char StrADC=0;

#define STR_CHANGE_DELAY 1

Treat_Type_Def OuTu;

const int code OuTuStrTable[5] = {255,235,220,200,180};
const int code OuTuStrTableMax[5] = {245,230,210,180,100};


static void str_change(void)
{
	int strEnsure;
	StrChangeDelay++;
	if(StrChangeDelay>=STR_CHANGE_DELAY)
	{
		StrChangeDelay = 0;
		if(StrChangeMode==0)
		{
			StrChange++;
			if(StrChange>20&&StrChange<=40)
				StrBuf += OuTu.str+1;
			if(StrChange==60)
			{
				StrChangeMode = 1;
			}
		}
		else
		{
			StrChange--;
			if(StrChange>20&&StrChange<=40)
				StrBuf -= OuTu.str+1;
			if(StrChange==0)
			{
				StrChangeMode = 0;	
			}
		}
		if(StrChange<=20)
		{
			CCAPM0 = 0x40;
		//	PWM0_SetHighReg(OuTuStrTable[OuTu.str]);	
		}
		else if(StrChange<=40)
		{
			strEnsure = 255-StrBuf-StrADC-OuTu.str*3;
			if(strEnsure>255)
			{
				strEnsure = 255;
			}
			if(strEnsure<OuTuStrTableMax[OuTu.str]-((StrADC*4)/10))
				strEnsure=OuTuStrTableMax[OuTu.str]-((StrADC*4)/10);
			PWM0_SetHighReg(strEnsure);
			CCAPM0 = 0x42;
		}
		else if(StrChange<=60)
		{
			strEnsure = 255-20*(OuTu.str+1)-StrADC-OuTu.str*3;
			if(strEnsure<OuTuStrTableMax[OuTu.str]-((StrADC*4)/10))
				strEnsure=OuTuStrTableMax[OuTu.str]-((StrADC*4)/10);
			PWM0_SetHighReg(strEnsure);
			CCAPM0 = 0x42;
		}		
	}

}

void OuTu_Treat()
{
	
	str_change();
	
	if(OuTu.wave==zheng)
	{
		OuTu.wave = fu;
	 	CHL = 1;
		CHR = 0;
		Delay10us(2);
		CHL = 0;
		CHR = 0;	
	}
	else if(OuTu.wave==fu)
	{
	 	OuTu.wave = zheng;
	 	CHL = 0;
		CHR = 1;
		Delay10us(2);
		CHL = 0;
		CHR = 0;
	}
}



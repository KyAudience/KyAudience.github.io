#include "ADC.h"

ADC_Type_Def Battery;

void InitADC()	    //10λADC��׼��ѹ3V
{
    P1ASF = 0x0C;                   //����P1��ΪAD��
    ADC_RES = 0;                    //�������Ĵ���
    ADC_CONTR = ADC_POWER | ADC_SPEEDLL;
		Delayms(5);
//    Delay(2);                       //ADC�ϵ粢��ʱ	
//	Battery.adc = GetADCResult(2)*0.0548;
}

uint8 GetADCResult(uint8 ch)
{
    ADC_CONTR = ADC_POWER | ADC_SPEEDLL | ch | ADC_START;
    _nop_();                        //�ȴ�4��NOP
    _nop_();
    _nop_();
    _nop_();
    while (!(ADC_CONTR & ADC_FLAG));//�ȴ�ADCת�����
    ADC_CONTR &= ~ADC_FLAG;         //Close ADC

    return ADC_RES;                 //����ADC���
}


unsigned char lvbo(unsigned char value[10])
{
  
  char i=0,j=0,k=0;

  int t=0;
  int value_lvbo=0;
  for(i=0;i<9;i++)
  {
    for(j=0;j<9-i;j++)
    {
      if(value[j]>value[j+1])
      {
        t=value[j];
        value[j] = value[j+1];
        value[j+1] = t;
      }
    }	
  }
  
  for(k=1;k<9;k++)
    value_lvbo += value[k];
  
  value_lvbo = value_lvbo/8;
  
  return value_lvbo;
}


void BatProcess(void)
{
	  int StrADCBuf = 0;
		if(Dc_On)
		{
			Battery.adcBuff[Battery.count++] = GetADCResult(2);
			if(Battery.count>=COUNT_MAX)
			{
				Battery.count %= COUNT_MAX;
				
				Battery.adc[1] = Battery.adc[0];
				Battery.adc[0] = lvbo(Battery.adcBuff);

				if(Battery.adc[0]>=81)
				{
					if(Battery.fullCount>CHARGE_DELAY)
					{
						Battery.state = full;
					}
					else
					{
						Battery.state = unfull;
						Battery.fullCount++;
					}
				}
				else 
				{
					Battery.state = unfull;
				}
			} 
		}
		else
		{
				Battery.adcBuff[Battery.count++] = GetADCResult(2);
				if(Battery.count>=COUNT_MAX)
				{
					Battery.count %= COUNT_MAX;
					
					Battery.adc[1] = Battery.adc[0];
					Battery.adc[0] = lvbo(Battery.adcBuff);
					if(OuTu.onceTreat==1)
					{
						if(Battery.adc[0]>Battery.adc[1])
						{
						//	Battery.adc[0] = Battery.adc[1];
						}
					}
					else
						OuTu.onceTreat = 1;
					
					StrADCBuf = Battery.adc[0]-83;
					
					StrADCBuf = (StrADCBuf>0) ? StrADCBuf : (-StrADCBuf);
					StrADCBuf = StrADCBuf*(90+OuTu.str*40);
					StrADCBuf = StrADCBuf/100;
					
					StrADC = StrADCBuf;
					if(Battery.adc[0]>=69)
						Battery.state = high;
					else if(Battery.adc[0]>=67)
						Battery.state = low;
					else if(Battery.adc[0]<67)
					{
						EventSet(SHUTDOWN_EVT);	
					}
				}
		}
}



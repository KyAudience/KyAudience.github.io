#ifndef __TIMER_H_
#define __TIMER_H_

#include "include.h"

void Timer0Init(void);
void Delayms(int x);
void Delay10us(int x);

#endif

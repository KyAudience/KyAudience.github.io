#ifndef __TREAT_H_
#define __TREAT_H_

#include "include.h"  

typedef struct
{
	char str;
	char wave;
	char onceTreat;
	int count;
	int shutdowntime;
}Treat_Type_Def;

enum maichong 
{
	zheng = 0,
	fu,
};

extern const int code OuTuStrTable[5];

extern bit StrChangeMode;
extern char StrChangeDelay;
extern char StrBuf;
extern char StrChange;
extern char StrADC;

extern Treat_Type_Def OuTu;

void OuTu_Treat(void);

#endif
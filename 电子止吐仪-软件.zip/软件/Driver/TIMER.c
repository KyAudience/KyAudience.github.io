#include "TIMER.h"

void Delayms(int x)		//@12.000MHz
{
	unsigned char i, j;
	do
	{
		i = 12;
		j = 169;
		do
		{
			while (--j);
		} while (--i);
	}while(--x);
}

void Delay10us(int x)		//@12.000MHz
{
	unsigned char i;
	do
	{
		_nop_();
		_nop_();
		i = 28;
		while (--i);	
	}while(--x);
}


void Timer0Init(void)
{
	TMOD = 0X01;
	TH0=(65536-1000)/256;
	TL0=(65536-1000)%256;
  ET0=1;
 	TR0=1;
}

void EventTimer(void) interrupt 1
{
	static int Timer1msCount;
	static int Timer50msCount;
	static int Timer1sCount;
	static int RedBreathCount;
 	TH0=(65536-1000)/256;
	TL0=(65536-1000)%256;
	Timer1msCount++;
	Timer1sCount++;
	Timer50msCount++;
	  
	 if(Red_Blink.count>0)
     Red_Blink.count--;
	
		RedBreathCount++;
    if(RedBreathCount>=10)
    {
      RedBreathCount = 0;
      LED_Breath_Frequency();
    }
	
	if(Dc_On)
	{
		PowerEn = 0;
		if(Timer1msCount>=1)
		{
			Timer1msCount = 0;
		}
		
		if(Timer50msCount>=50)
		{
		 	Timer50msCount = 0;
			EventSet(BAT_EVT);
		}
		
		if(Timer1sCount>=1000)
		{
			Timer1sCount = 0;

		//	EventSet(UART_EVT);
			
		}	

	}
	else
	{
		if(Timer1msCount>=1)
		{
			Timer1msCount = 0;
			EventSet(KEY_EVT);

			if(Blue.count>0)
			{
			 	Blue.count--;
				if(Blue.count==0)
				{
				 	EventSet(LED_BLINK_EVT);
				}
			}
			
			OuTu.count++;
			if(OuTu.count==33)
			{
			 	OuTu.count = 0;
				if((OuTu.onceTreat)&&(keyPower.press != longpress)&&(Battery.adc[0]>=67))
					OuTu_Treat();
			}
		}
		
		if(Timer50msCount>=50)
		{
			Timer50msCount = 0;
			EventSet(BAT_EVT);
		}
	
		if(Timer1sCount>=1000)
		{
			Timer1sCount = 0;
			OuTu.shutdowntime--;
			if(OuTu.shutdowntime<=0)
			{
				EventSet(SHUTDOWN_EVT);
			}
			
//			EventSet(UART_EVT);
			
		}	
	}
}

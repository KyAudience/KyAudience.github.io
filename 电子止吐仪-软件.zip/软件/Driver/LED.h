#ifndef __LED_H_
#define __LED_H_

#include "include.h"

#define ALL_LED_ON			LED1 = 0;LED2 = 0;LED3 = 0;LED4 = 0;LED5 = 0;
#define ALL_LED_OFF 		LED1 = 1;LED2 = 1;LED3 = 1;LED4 = 1;LED5 = 1;
#define LED1_ON       LED1 = 0;LED2 = 1;LED3 = 1;LED4 = 1;LED5 = 1;
#define LED2_ON				LED1 = 1;LED2 = 0;LED3 = 1;LED4 = 1;LED5 = 1;
#define LED3_ON				LED1 = 1;LED2 = 1;LED3 = 0;LED4 = 1;LED5 = 1;
#define LED4_ON				LED1 = 1;LED2 = 1;LED3 = 1;LED4 = 0;LED5 = 1;
#define LED5_ON				LED1 = 1;LED2 = 1;LED3 = 1;LED4 = 1;LED5 = 0;

#define LED_R_ON 			LED1_R=0
#define LED_R_OFF   	LED1_R=1

typedef enum 
{
	ON = 0,
	OFF,
}LED_Type_Def;

typedef struct
{
  unsigned char LedState;
  unsigned char LedWidthState;
  unsigned int LedWidth;
  unsigned int LedBright;
}LED_Breath_Type_Def;

typedef struct
{
	int count;
	char state;
}LED_BLINK_Type_Def;

extern LED_BLINK_Type_Def Blue;
extern LED_Breath_Type_Def Red_Breath;
extern LED_BLINK_Type_Def Red_Blink;

void LED_Display(LED_Type_Def state);
void LED_CHARGE(void);
void LED_Blink(void);
void LED_Breath(void);
void LED_Breath_Frequency(void);
void LED_LowBat_Blink(void);


#endif
#ifndef __INCLUDE_H_
#define __INCLUDE_H_

#include "reg52.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include "intrins.h"
#include "KEY.h"
#include "PCA.h"
#include "TREAT.h"
#include "ADC.h"
#include "TIMER.h"
#include "EVENT.h"
#include "PERIPHERAL.h"
#include "LED.h"
#include "UART.h"

typedef unsigned char uint8;
typedef unsigned int uint16;
typedef unsigned long uint32;

typedef signed char int8;
typedef signed int int16;
typedef signed long int32;

sfr  P0M1 =	0x93;
sfr  P0M0 = 0x94;

sfr  P1M1 = 0x91;
sfr  P1M0 = 0x92;

sfr	 P2M1 = 0x95;
sfr	 P2M0 = 0x96;

sfr	 P3M1 = 0xB1;
sfr  P3M0 = 0xB2;

#define EnableAllInterrupts   EA=1
#define DisableAllInterrupts  EA=0

#endif

#include "include.h"

#define SHUT_DOWN_TIME 28800

void DATA_Init(void);
void IO_Init(void);

void main()
{
	DisableAllInterrupts;
	DATA_Init();
	IO_Init();
	PowerEn = 0;   //�ϵ������
	Timer0Init();
	//InitUart();
	InitADC();
	PWM0_init(OuTuStrTable[OuTu.str]);
	if(Power)
	{
		Delayms(500);
		PowerEn = 1;
	}
	EnableAllInterrupts;
	if(!Dc_On)
	{
		LED_Display(ON);
		LED_Display(ON);
	}
	Blue.count = 1000;
	Blue.state = 0;
	while(1)
	{
	  EventProcess();	   //�¼�����
		KeyScan();   //�������
		if(Dc_On)
		{
			CCAPM0 = 0x40;  //DAC no output
			LED_CHARGE();   //���ָʾ
		}
		else
		{
			if(Battery.state==low)
			{
				LED_LowBat_Blink(); //�͵���ָʾ
			}
			else
			{
				LED_R_OFF;   //����״̬LED�޷�Ӧ
			}
		}
	}	
}

void DATA_Init(void)
{
	memset(&keyPower,0,sizeof(keyPower));
	memset(&OuTu,0,sizeof(OuTu));
	memset(&Blue,0,sizeof(Blue));
	memset(&Battery,0,sizeof(Battery));

 	eventBuff = 0;

	OuTu.str = 0;
	OuTu.shutdowntime = SHUT_DOWN_TIME;
	Battery.state = high;
}

void IO_Init(void)
{
	P1M0 = 0X03;
	P1M1 = 0X0C;

	P2M0 = 0XFC;
	P2M1 = 0X01;

	P3M0 = 0XC0;
	P3M1 = 0X30;

	CCP0 = 0;
	LED1 = 1;
	LED2 = 1;
	LED3 = 1;
	LED4 = 1;
	LED5 = 1;
	LED1_R = 1;
	CHL = 0;
	CHR = 0;
	ELEC = 1;
}

